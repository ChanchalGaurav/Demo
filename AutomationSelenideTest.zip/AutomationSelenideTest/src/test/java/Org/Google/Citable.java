package Org.Google;

import static com.codeborne.selenide.Condition.ownText;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.byAttribute;
import static com.codeborne.selenide.Selectors.byCssSelector;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static com.codeborne.selenide.Selenide.open;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.codeborne.selenide.SelenideElement;
public class Citable {
	private static final String PAGE_TITLE = "MDX Browser";
	private static final String PAGE_RELATIVE_URL = "/browser/dataset";
	private static final SelenideElement DATASET_PAGE_TITLE = $("title");
	private static final SelenideElement ACCESSIBILITY_SCROLL = $(byText("Accessibility"));
	private static final SelenideElement CITABLEAS_LABLE = $(byText("Citable As:"));
	private static final SelenideElement SUMMARY_SECTION_TITLE = $(byAttribute("data-testid", "summary-list-title"));
	private static final SelenideElement ACCESSIBILITY_SECTION_TITLE = $(byAttribute("data-testid", "accessibility-list-title"));
	private static final SelenideElement CITABLEAS_String = $(byCssSelector(".sc-iTVIwl"));
	private static final String CITABLE_TEXT="QA Team at MetadataWorks (2021): IPCC V1 Automated API Test Dataset. MetadataWorks, \n" +
            ". 10.1234/456-mydoc-456584893489";

	@Test
	public void tooltip() throws InterruptedException {
	open("https://test.metadatadev.co.uk/browser/dataset?id=543329");
	Thread.sleep(5000);
	$(By.xpath("//button[@data-testid='cookie-consent-modal-accept']")).click();

	boolean title_result = $("title").shouldHave(ownText(PAGE_TITLE)).exists();
	System.out.println(title_result);
	executeJavaScript("arguments[0].click();", ACCESSIBILITY_SCROLL);
	
	boolean accessibility = CITABLEAS_LABLE.shouldBe(visible).isDisplayed();
	System.out.println(accessibility);
	String Text_Citable = CITABLEAS_String.getText();

	  boolean res= CITABLEAS_String.shouldHave(ownText(CITABLE_TEXT)).exists();
	  System.out.println(res);
	Thread.sleep(3000);

	}

	
}


